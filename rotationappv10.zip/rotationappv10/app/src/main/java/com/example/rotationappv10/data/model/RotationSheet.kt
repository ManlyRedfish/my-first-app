// data/model/RotationSheet.kt
package com.example.rotationappv10.data.model

data class RotationSheet(
    val date: String,
    val shift: String,
    val assignments: List<Assignment>
)