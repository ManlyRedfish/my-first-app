// File: ui/main/MainInputScreen.kt
package com.example.rotationappv10.ui.main

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.rotationappv10.viewmodel.MainViewModel
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Calendar

@Composable
fun MainInputScreen(onGenerateRotation: (Calendar?) -> Unit) {
    val viewModel: MainViewModel = viewModel()
    var selectedDate by remember { mutableStateOf<Calendar?>(null) }
    val context = LocalContext.current
    val calendar = Calendar.getInstance()

    var selectedShift by remember { mutableStateOf("AM") }
    val selectedTime by viewModel.selectedShiftTime.collectAsState()

    // Get state from ViewModel -  CORRECTED collectAsState usage
    val selectedCheckpoint by viewModel.selectedCheckpoint.collectAsState()
    val selectedLane by viewModel.selectedLane.collectAsState()
    val selectedLead by viewModel.selectedLead.collectAsState()
    val selectedSupervisor by viewModel.selectedSupervisor.collectAsState()


    val dateSetListener = DatePickerDialog.OnDateSetListener { _, year, month, dayOfMonth ->
        val newCalendar = Calendar.getInstance()
        newCalendar.set(year, month, dayOfMonth)
        selectedDate = newCalendar
        viewModel.updateSelectedDate(newCalendar.toInstant().atZone(java.time.ZoneId.systemDefault()).toLocalDate())
    }

    val datePickerDialog = DatePickerDialog(
        context,
        dateSetListener,
        calendar.get(Calendar.YEAR),
        calendar.get(Calendar.MONTH),
        calendar.get(Calendar.DAY_OF_MONTH)
    )

    val timePickerDialog = TimePickerDialog(
        context,
        { _, hourOfDay, minute ->
            viewModel.updateSelectedShiftTime(LocalTime.of(hourOfDay, minute))
        },
        selectedTime?.hour ?: LocalTime.now().hour,
        selectedTime?.minute ?: LocalTime.now().minute,
        false // Use AM/PM format
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top
    ) {
        OfficerInputForm(onAddOfficer = { name, certifications, startTime, gender, isFullTime, officerCount ->
            if (name.isNotBlank()) {
                viewModel.addOfficer(name, certifications, startTime, gender, isFullTime)
            } else {
                for (i in 1..officerCount) {
                    viewModel.addOfficer("Officer $i", certifications, startTime, gender, isFullTime)
                }
            }
        })
        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = { datePickerDialog.show() }) {
            Text(text = selectedDate?.let {
                "${it.get(Calendar.MONTH) + 1}/${it.get(Calendar.DAY_OF_MONTH)}/${it.get(Calendar.YEAR)}"
            } ?: "Select Date")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Shift:")
            Spacer(modifier = Modifier.width(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(
                    selected = selectedShift == "AM",
                    onClick = {
                        selectedShift = "AM"
                        viewModel.updateSelectedShift("AM") // Update ViewModel
                    }
                )
                Text(
                    text = "AM",
                    modifier = Modifier.clickable {
                        selectedShift = "AM"
                        viewModel.updateSelectedShift("AM") // Update ViewModel
                    }
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(
                    selected = selectedShift == "PM",
                    onClick = {
                        selectedShift = "PM"
                        viewModel.updateSelectedShift("PM") // Update ViewModel
                    }
                )
                Text(
                    text = "PM",
                    modifier = Modifier.clickable {
                        selectedShift = "PM"
                        viewModel.updateSelectedShift("PM") // Update ViewModel
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = { timePickerDialog.show() }) {
            Text(text = selectedTime?.format(DateTimeFormatter.ofPattern("h:mm a")) ?: "Select Shift Start Time")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = {
            viewModel.updateSelectedShift(selectedShift)
            //Update the ViewModel's values BEFORE generating:
            viewModel.updateSelectedCheckpoint(selectedCheckpoint)
            viewModel.updateSelectedLane(selectedLane)
            viewModel.updateSelectedLead(selectedLead)
            viewModel.updateSelectedSupervisor(selectedSupervisor)


            onGenerateRotation(selectedDate) //Still pass the calendar for now
            //Could call viewModel.generateRotationAndPdf() directly here,
            //but keeping the separation for now.
        }) {
            Text("Generate Rotation")
        }
    }
}

@Preview(showBackground = true)
@Composable
fun MainInputScreenPreview() {
    MaterialTheme {
        MainInputScreen(onGenerateRotation = {})
    }
}