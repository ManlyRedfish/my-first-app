// File: ui/main/OfficerInputForm.kt
package com.example.rotationappv10.ui.main

import android.app.TimePickerDialog
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import java.util.Calendar
import kotlinx.coroutines.launch // Import for coroutines

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OfficerInputForm(onAddOfficer: (String, List<String>, String, String, Boolean, Int) -> Unit) {
    var name by remember { mutableStateOf("") }
    val availableCertifications = listOf("XRay", "SST", "DO", "None")
    var certificationsExpanded by remember { mutableStateOf(false) }
    var selectedCerts by remember { mutableStateOf(listOf<String>()) }
    var startTime by remember { mutableStateOf("08:00") }
    val genderOptions = listOf("Male", "Female", "Other")
    var selectedGender by remember { mutableStateOf(genderOptions[0]) }
    var isFullTime by remember { mutableStateOf(true) }

    val checkpoints = listOf("Checkpoint A", "Checkpoint B", "Checkpoint C", "Checkpoint-Wide")
    var checkpointExpanded by remember { mutableStateOf(false) }
    var selectedCheckpoint by remember { mutableStateOf("") }

    val lanes = listOf("Lane 1", "Lane 2", "Lane 3", "Lane 4", "Lane 5")
    var laneExpanded by remember { mutableStateOf(false) }
    var selectedLane by remember { mutableStateOf("") }

    var lead by remember { mutableStateOf("") }
    var supervisor by remember { mutableStateOf("") }

    var officerCountInputMode by remember { mutableStateOf(false) }
    var officerCount by remember { mutableStateOf(1) }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope() // Get a CoroutineScope


    fun showTimePicker() {
        val calendar = Calendar.getInstance()
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        val minute = calendar.get(Calendar.MINUTE)

        TimePickerDialog(
            context,
            { _, hourOfDay, minuteOfHour ->
                startTime = String.format("%02d:%02d", hourOfDay, minuteOfHour)
            },
            hour,
            minute,
            true
        ).show()
    }

    Column(modifier = Modifier.padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Input Names:")
            Spacer(modifier = Modifier.width(8.dp))
            Switch(
                checked = officerCountInputMode,
                onCheckedChange = { officerCountInputMode = it }
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (!officerCountInputMode) {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Officer Name") },
                modifier = Modifier.fillMaxWidth(),
                isError = name.isBlank()
            )
        } else {
            OutlinedTextField(
                value = officerCount.toString(),
                onValueChange = {
                    officerCount = it.toIntOrNull() ?: 1
                },
                label = { Text("Number of Officers") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        ExposedDropdownMenuBox(
            expanded = certificationsExpanded,
            onExpandedChange = { certificationsExpanded = !certificationsExpanded }
        ) {
            TextField(
                modifier = Modifier
                    .menuAnchor()
                    .fillMaxWidth(),
                readOnly = true,
                value = selectedCerts.joinToString(", "),
                onValueChange = {},
                label = { Text("Certifications") },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = certificationsExpanded) },
                colors = ExposedDropdownMenuDefaults.textFieldColors(),
            )
            ExposedDropdownMenu(
                expanded = certificationsExpanded,
                onDismissRequest = { certificationsExpanded = false },
            ) {
                availableCertifications.forEach { certification ->
                    DropdownMenuItem(
                        text = { Text(certification) },
                        onClick = {
                            if (selectedCerts.contains(certification)) {
                                selectedCerts = selectedCerts - certification
                            } else {
                                selectedCerts = selectedCerts + certification
                            }
                        },
                        contentPadding = ExposedDropdownMenuDefaults.ItemContentPadding,
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = startTime,
            onValueChange = { /* Read-only */ },
            label = { Text("Start Time") },
            modifier = Modifier
                .fillMaxWidth()
                .clickable { showTimePicker() },
            enabled = false,
            colors = ExposedDropdownMenuDefaults.textFieldColors()
        )
        Spacer(modifier = Modifier.height(8.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            genderOptions.forEach { text ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(
                        selected = (text == selectedGender),
                        onClick = { selectedGender = text }
                    )
                    Text(
                        text = text,
                        modifier = Modifier.clickable(onClick = { selectedGender = text })
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Full-Time")
            Spacer(modifier = Modifier.width(8.dp))
            Switch(
                checked = isFullTime,
                onCheckedChange = { isFullTime = it }
            )
        }
        Spacer(modifier = Modifier.height(8.dp))

        ExposedDropdownMenuBox(
            expanded = checkpointExpanded,
            onExpandedChange = { checkpointExpanded = !checkpointExpanded }
        ) {
            TextField(
                modifier = Modifier
                    .menuAnchor()
                    .fillMaxWidth(),
                readOnly = true,
                value = selectedCheckpoint,
                onValueChange = {},
                label = { Text("Checkpoint") },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = checkpointExpanded) },
                colors = ExposedDropdownMenuDefaults.textFieldColors()
            )
            ExposedDropdownMenu(
                expanded = checkpointExpanded,
                onDismissRequest = { checkpointExpanded = false },
            ) {
                checkpoints.forEach { checkpoint ->
                    DropdownMenuItem(
                        text = { Text(checkpoint) },
                        onClick = {
                            selectedCheckpoint = checkpoint
                            checkpointExpanded = false
                            selectedLane = ""
                        },
                        contentPadding = ExposedDropdownMenuDefaults.ItemContentPadding
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(8.dp))

        ExposedDropdownMenuBox(
            expanded = laneExpanded,
            onExpandedChange = { laneExpanded = !laneExpanded }
        ) {
            TextField(
                modifier = Modifier
                    .menuAnchor()
                    .fillMaxWidth(),
                readOnly = true,
                value = selectedLane,
                onValueChange = {},
                label = { Text("Lane") },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = laneExpanded) },
                colors = ExposedDropdownMenuDefaults.textFieldColors(),
                enabled = selectedCheckpoint.isNotBlank()
            )
            ExposedDropdownMenu(
                expanded = laneExpanded,
                onDismissRequest = { laneExpanded = false },
            ) {
                val filteredLanes = if (selectedCheckpoint == "Checkpoint-Wide") {
                    lanes
                } else {
                    lanes.filter { it.startsWith("Lane") }
                }

                filteredLanes.forEach { lane ->
                    DropdownMenuItem(
                        text = { Text(lane) },
                        onClick = {
                            selectedLane = lane
                            laneExpanded = false
                        },
                        contentPadding = ExposedDropdownMenuDefaults.ItemContentPadding
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = lead,
            onValueChange = { lead = it },
            label = { Text("Lead") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = supervisor,
            onValueChange = { supervisor = it },
            label = { Text("Supervisor") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))

        // Use LaunchedEffect to delay the updates
        Button(onClick = {
            coroutineScope.launch { // Launch a coroutine
                if (!officerCountInputMode && name.isNotBlank()) {
                    onAddOfficer(name, selectedCerts, startTime, selectedGender, isFullTime, 1)
                    name = ""
                    selectedCerts = listOf()
                    startTime = "08:00"
                    selectedGender = genderOptions[0]
                    isFullTime = true
                } else if (officerCountInputMode && officerCount > 0) {
                    onAddOfficer("", selectedCerts, startTime, selectedGender, isFullTime, officerCount)
                }
            }
        }) {
            Text("Add Officer(s)")
        }
    }
}