// data/model/Officer.kt
package com.example.rotationappv10.data.model

data class Officer(
    val name: String,
    val certifications: List<String>,
    val startTime: String,
    val gender: String,
    val isFullTime: Boolean = true // Add isFullTime property
)