// data/model/ShiftSetting.kt
package com.example.rotationappv10.data.model

data class ShiftSetting(
    val startTime: String,
    val interval: Int
)