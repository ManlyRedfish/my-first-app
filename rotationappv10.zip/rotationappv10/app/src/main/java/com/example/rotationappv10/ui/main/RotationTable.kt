// File: ui/main/RotationTable.kt
package com.example.rotationappv10.ui.main

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.lazy.LazyColumn // Import LazyColumn (or Column if list is short)
import androidx.compose.foundation.lazy.items // Import items extension function
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import com.example.rotationappv10.data.model.Assignment
import com.example.rotationappv10.data.model.RotationSheet

@Composable
fun RotationTable(rotationSheet: RotationSheet) {
    Column { // Keep the outer Column for headers and the LazyColumn
        // Display table headers
        Row {
            Text("Time Slot")
            Text("Officer")
            Text("Position")
        }

        // Display assignments using LazyColumn for efficient list rendering
        LazyColumn { // Or use Column if the list is small and doesn't need lazy loading
            items(rotationSheet.assignments) { assignment -> // Use items extension
                AssignmentRow(assignment = assignment) // Composable call within items lambda
            }
        }
    }
}

@Composable
fun AssignmentRow(assignment: Assignment) {
    Row {
        Text(assignment.timeSlot)
        Text(assignment.officer?.name ?: "Unassigned")
        Text(assignment.positionKey?.code ?: "N/A")
    }
}