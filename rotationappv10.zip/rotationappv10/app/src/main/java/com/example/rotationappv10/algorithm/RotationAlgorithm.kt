package com.example.rotationappv10.algorithm

import com.example.rotationappv10.data.model.Assignment
import com.example.rotationappv10.data.model.Officer
import com.example.rotationappv10.data.model.PositionKey
import com.example.rotationappv10.data.model.ShiftSetting
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import android.util.Log // Import Log

private const val TAG = "RotationAlgorithm" // Define a tag for logging

class RotationAlgorithm {

    fun generateRotation(
        officers: List<Officer>,
        positionKeys: List<PositionKey>,
        shiftSetting: ShiftSetting
    ): List<Assignment> {
        Log.d(TAG, "generateRotation called with:")
        Log.d(TAG, "  Officers: $officers")
        Log.d(TAG, "  Position Keys: $positionKeys")
        Log.d(TAG, "  Shift Setting: $shiftSetting")

        val assignments = mutableListOf<Assignment>()
        val timeSlots = generateTimeSlots(shiftSetting)
        Log.d(TAG, "Generated Time Slots: $timeSlots")

        val breakPositionKey = positionKeys.firstOrNull { it.isBreak }
            ?: PositionKey("BRK", "Break", false, listOf(), true)
        Log.d(TAG, "Break Position Key: $breakPositionKey")

        for (timeSlot in timeSlots) {
            val availableOfficersForTimeSlot = officers.toMutableList() // All officers are initially available
            Log.d(TAG, "Processing time slot: $timeSlot")

            // --- Assign Breaks First ---
            for (officer in officers) {
                val breakTimes = calculateBreakTimes(officer, shiftSetting)
                val isAssigned = assignments.any { it.officer == officer && it.timeSlot == timeSlot }
                Log.d(TAG, "  Checking officer: ${officer.name}, Break Times: $breakTimes, Already Assigned: $isAssigned")
                if (!isAssigned && breakTimes.contains(timeSlot) && isOfficerAvailable(officer, timeSlot)) {
                    Log.d(TAG, "    Assigning BREAK to ${officer.name} at $timeSlot")
                    assignments.add(
                        Assignment(
                            timeSlot = timeSlot,
                            officer = officer,
                            positionKey = breakPositionKey
                        )
                    )
                    availableOfficersForTimeSlot.remove(officer) // Remove after break assignment
                } else {
                    Log.d(TAG, "    Not assigning break to ${officer.name} at $timeSlot") // Log when not assigning
                }
            }

            // --- Assign Regular Positions ---
            Log.d(TAG, "  Assigning regular positions. Available officers: $availableOfficersForTimeSlot")
            for (officer in availableOfficersForTimeSlot) { // Iterate through *remaining* available officers
                val isAssigned = assignments.any{ it.officer == officer && it.timeSlot == timeSlot}
                Log.d(TAG, "    Checking officer: ${officer.name}, Already Assigned: $isAssigned")
                // Check Officer Start time
                if(!isAssigned && isOfficerAvailable(officer, timeSlot)) {
                    Log.d(TAG, "      Officer ${officer.name} is available for time slot $timeSlot")
                    val positionKey =
                        positionKeys.firstOrNull { !it.isBreak && canAssign(officer, it) }
                    if (positionKey != null) {
                        Log.d(TAG, "        Assigning position ${positionKey.code} to ${officer.name} at $timeSlot")
                        assignments.add(
                            Assignment(
                                timeSlot = timeSlot,
                                officer = officer,
                                positionKey = positionKey
                            )
                        )
                    } else {
                        Log.d(TAG, "        No valid position found for ${officer.name} at $timeSlot") // Log when no position is found
                    }
                } else {
                    Log.d(TAG, "     Officer ${officer.name} NOT available for time slot $timeSlot")
                }
            }
        }
        Log.d(TAG, "Final Assignments: $assignments")
        return assignments
    }
    private fun isOfficerAvailable(officer: Officer, timeSlot: String): Boolean{
        val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
        val officerStartTime = sdf.parse(officer.startTime)
        val slotTime = sdf.parse(timeSlot)

        val officerStartCalendar = Calendar.getInstance().apply {
            time = officerStartTime!!
        }

        val slotCalendar = Calendar.getInstance().apply {
            time = slotTime!!
        }
        val isAvailable = slotCalendar.timeInMillis >= officerStartCalendar.timeInMillis
        Log.d(TAG, "isOfficerAvailable(${officer.name}, $timeSlot): $isAvailable") // Log result
        return isAvailable
    }

    private fun generateTimeSlots(shiftSetting: ShiftSetting): List<String> {
        val timeSlots = mutableListOf<String>()
        val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
        val calendar = Calendar.getInstance()
        calendar.time = sdf.parse(shiftSetting.startTime)!!

        val endTime = Calendar.getInstance().apply {
            time = calendar.time
            add(Calendar.HOUR, 8) // Generate slots for 8 hours
        }
        Log.d(TAG, "generateTimeSlots: Start Time = ${shiftSetting.startTime}, Interval = ${shiftSetting.interval}, End Time = ${sdf.format(endTime.time)}")


        while (calendar.before(endTime)) {
            timeSlots.add(sdf.format(calendar.time))
            calendar.add(Calendar.MINUTE, shiftSetting.interval)
        }

        return timeSlots
    }

    private fun calculateBreakTimes(officer: Officer, shiftSetting: ShiftSetting): List<String> {
        val breakTimes = mutableListOf<String>()
        val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
        val startTime = sdf.parse(officer.startTime) ?: return breakTimes
        val startCalendar = Calendar.getInstance() // Corrected instance creation
        startCalendar.time = startTime
        Log.d(TAG, "calculateBreakTimes for ${officer.name}, Start Time: ${officer.startTime}, isFullTime: ${officer.isFullTime}")


        if (officer.isFullTime) {
            // 15-30-15 pattern
            val break1 = (startCalendar.clone() as Calendar).apply { add(Calendar.MINUTE, shiftSetting.interval * 2) }
            val break2 = (startCalendar.clone() as Calendar).apply { add(Calendar.HOUR, 4) }
            val break3 = (startCalendar.clone() as Calendar).apply { add(Calendar.HOUR, 7) }


            breakTimes.add(sdf.format(break1.time))
            breakTimes.add(sdf.format(break2.time))
            breakTimes.add(sdf.format(break3.time))
            Log.d(TAG, "  Full-time breaks: ${breakTimes.joinToString()}")


        } else {
            // Single 15-minute break
            val break1 = (startCalendar.clone() as Calendar).apply { add(Calendar.HOUR, 2) }
            breakTimes.add(sdf.format(break1.time))
            Log.d(TAG, " Part-time break: ${breakTimes.joinToString()}")
        }

        return breakTimes
    }


    private fun canAssign(officer: Officer, positionKey: PositionKey): Boolean {
        // Check Certifications (for now, just a basic check)
        val canAssign = officer.certifications.contains(positionKey.code)
        Log.d(TAG, "canAssign(${officer.name}, ${positionKey.code}): $canAssign (Officer Certs: ${officer.certifications})")
        return canAssign
    }
}