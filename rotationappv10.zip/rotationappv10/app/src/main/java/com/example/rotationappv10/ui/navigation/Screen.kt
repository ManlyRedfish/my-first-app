// File: ui/navigation/Screen.kt
package com.example.rotationappv10.ui.navigation

import androidx.annotation.StringRes
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Place
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.rotationappv10.R

sealed class Screen(val route: String, @StringRes val resourceId: Int, val icon: ImageVector) {
    object Main : Screen("main", R.string.main_screen_title, Icons.Filled.Home)
    object Personnel : Screen("personnel", R.string.personnel_screen_title, Icons.Filled.Person)
    object Location : Screen("location", R.string.location_screen_title, Icons.Filled.Place)
}