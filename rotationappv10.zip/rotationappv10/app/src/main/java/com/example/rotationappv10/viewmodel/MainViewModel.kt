// File: viewmodel/MainViewModel.kt
package com.example.rotationappv10.viewmodel

import android.content.Context
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.example.rotationappv10.algorithm.RotationAlgorithm
import com.example.rotationappv10.data.model.Assignment
import com.example.rotationappv10.data.model.Officer
import com.example.rotationappv10.data.model.PositionKey
import com.example.rotationappv10.data.model.RotationSheet
import com.example.rotationappv10.data.model.ShiftSetting
import com.example.rotationappv10.pdf.PdfGenerator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Calendar

class MainViewModel : ViewModel() {

    private val _officers = MutableStateFlow<List<Officer>>(emptyList())
    val officers: StateFlow<List<Officer>> = _officers.asStateFlow()

    private val _rotationSheet = MutableStateFlow<RotationSheet?>(null)
    val rotationSheet: StateFlow<RotationSheet?> = _rotationSheet.asStateFlow()

    private val _selectedDate = MutableStateFlow<LocalDate>(LocalDate.now())
    val selectedDate: StateFlow<LocalDate> = _selectedDate.asStateFlow()

    fun updateSelectedDate(newDate: LocalDate) {
        _selectedDate.value = newDate
    }

    private val _selectedShift = MutableStateFlow("")
    val selectedShift: StateFlow<String> = _selectedShift.asStateFlow()

    fun updateSelectedShift(newShift: String) {
        _selectedShift.value = newShift // Use StateFlow
    }

    private val _selectedShiftTime = MutableStateFlow<LocalTime?>(null)
    val selectedShiftTime: StateFlow<LocalTime?> = _selectedShiftTime.asStateFlow()

    fun updateSelectedShiftTime(newTime: LocalTime) {
        _selectedShiftTime.value = newTime
    }
    private val _selectedCheckpoint = MutableStateFlow("")
    val selectedCheckpoint: StateFlow<String> = _selectedCheckpoint.asStateFlow()

    fun updateSelectedCheckpoint(newCheckpoint: String){
        _selectedCheckpoint.value = newCheckpoint //Use StateFlow
    }

    private val _selectedLane = MutableStateFlow("")
    val selectedLane: StateFlow<String> = _selectedLane.asStateFlow()
    fun updateSelectedLane(newLane: String) {
        _selectedLane.value = newLane // Use StateFlow
    }

    private val _selectedLead = MutableStateFlow("")
    val selectedLead: StateFlow<String> = _selectedLead.asStateFlow()

    fun updateSelectedLead(newLead: String){
        _selectedLead.value = newLead // Use StateFlow
    }

    private val _selectedSupervisor = MutableStateFlow("")
    val selectedSupervisor : StateFlow<String> = _selectedSupervisor.asStateFlow()
    fun updateSelectedSupervisor(newSupervisor: String){
        _selectedSupervisor.value = newSupervisor // Use StateFlow
    }
    var generatedPdfFile by mutableStateOf<File?>(null)
        private set
    var errorMessage by mutableStateOf<String?>(null)
        private set
    var blankDate by mutableStateOf(false)
        private set
    fun updateBlankDate(newBlankDate: Boolean){
        blankDate = newBlankDate
    }


    fun addOfficer(name: String, certifications: List<String>, startTime: String, gender: String, isFullTime: Boolean) {

        val newOfficer = Officer(name, certifications, startTime, gender, isFullTime)
        _officers.value = _officers.value + newOfficer

    }


    @RequiresApi(Build.VERSION_CODES.O)
    fun generateRotation(): RotationSheet {
        Log.d("MainViewModel", "generateRotation called")
        Log.d("MainViewModel", "Selected Date: ${selectedDate.value}")
        Log.d("MainViewModel", "Selected Shift: $selectedShift")   // Log the shift
        Log.d("MainViewModel", "Selected Shift Time: ${selectedShiftTime.value}") // Log the time


        val algorithm = RotationAlgorithm()

        val positionKeys = listOf(
            PositionKey("XRay", "X-Ray", false, listOf("XRay Certification")),
            PositionKey("SST", "SST", false, listOf("SST Certification")),
            PositionKey("DO", "Document Check", false, listOf()),
            PositionKey("BRK", "Break", true, listOf(), isBreak = true)
        )
        //val shiftSetting = ShiftSetting("06:00", 30)
        // Create ShiftSetting from the UI selections
        val shiftSetting = selectedShiftTime.value?.let {
            ShiftSetting(startTime = it.format(DateTimeFormatter.ofPattern("HH:mm")), interval = 30)
        } ?: ShiftSetting("06:00", 30) // Fallback to 06:00 if null


        val assignments = algorithm.generateRotation(
            officers = officers.value,
            positionKeys = positionKeys,
            shiftSetting = shiftSetting //Pass correct shiftsetting
        )
        val sheet = RotationSheet(date = selectedDate.value.toString(), shift = selectedShift.value, assignments = assignments) //Pass in shift here
        _rotationSheet.value = sheet
        return sheet
    }


    @RequiresApi(Build.VERSION_CODES.Q)
    fun generateRotationAndPdf(context: Context) {
        val rotationSheet = generateRotation()

        val positionKeys = listOf(
            PositionKey("XRay", "X-Ray", false, listOf("XRay Certification")),
            PositionKey("SST", "SST", false, listOf("SST Certification")),
            PositionKey("DO", "Document Check", false, listOf()),
            PositionKey("BRK", "Break", true, listOf(), isBreak = true)
        )

        val pdfGenerator = PdfGenerator(context)
        val pdfFile = pdfGenerator.generatePdf(
            rotationSheet,
            positionKeys,
            selectedCheckpoint.value,
            selectedLane.value,
            selectedLead.value,
            selectedSupervisor.value,
            selectedDate.value.toString(),
            selectedShift.value,
            blankDate
        )

        generatedPdfFile = pdfFile

        if (pdfFile == null) {
            errorMessage = "Failed to generate PDF."
        } else {
            errorMessage = null
        }
    }
}