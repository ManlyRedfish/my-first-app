// File: ui/main/HomeScreen.kt
package com.example.rotationappv10.ui.main

import android.util.Log
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Place
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.rotationappv10.R
import com.example.rotationappv10.ui.navigation.Screen
import com.example.rotationappv10.viewmodel.MainViewModel
import androidx.navigation.compose.rememberNavController // Correct Import
import androidx.navigation.compose.NavHost // Correct Import
import androidx.navigation.compose.composable // Correct Import
import androidx.navigation.NavController //Correct Import

private const val TAG = "HomeScreen"

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen() {
    val viewModel: MainViewModel = viewModel()
    // Use rememberNavController to create a NavController
    val navController = rememberNavController()

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White
            ) {
                val items = listOf(
                    Screen.Personnel,
                    Screen.Main,
                    Screen.Location,
                )
                // Use a single state variable for the selected screen
                var selectedScreen by remember { mutableStateOf<Screen>(Screen.Main) }

                items.forEach { screen ->
                    NavigationBarItem(
                        icon = { Icon(imageVector = screen.icon, contentDescription = screen.route) },
                        label = { Text(stringResource(screen.resourceId)) },
                        selected = selectedScreen == screen,
                        onClick = {
                            selectedScreen = screen // Update selected screen
                            navController.navigate(screen.route) {
                                // Pop up to the start destination of the graph to
                                // avoid building up a large stack of destinations
                                // on the back stack as users select items
                                popUpTo(navController.graph.startDestinationId) {
                                    saveState = true
                                }
                                // Avoid multiple copies of the same destination when
                                // reselecting the same item
                                launchSingleTop = true
                                // Restore state when reselecting a previously selected item
                                restoreState = true
                            }
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        // NavHost to manage navigation
        NavHost(
            navController = navController,
            startDestination = Screen.Main.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Main.route) {
                MainScreen(viewModel)
            }
            composable(Screen.Personnel.route) {
                PersonnelScreen() // Use the PersonnelScreen composable
            }
            composable(Screen.Location.route) {
                LocationScreen() // Use the LocationScreen composable
            }
        }
    }
}
//Composable for Main Screen
@Composable
fun MainScreen(viewModel: MainViewModel) {
    // Get the context at the composable level
    val context = LocalContext.current

    // Pass the captured context to the lambda
    MainInputScreen(onGenerateRotation = { calendar ->
        if (calendar != null) {
            viewModel.generateRotationAndPdf(context = context)
        }
    })
}

@Composable
fun PersonnelScreen() {
    // Placeholder content for now.  You'll move officer input here.
    Text("Personnel Screen Content - Officer Input will go here")
}

@Composable
fun LocationScreen() {
    // Placeholder content
    Text("Location Screen Content - Location Settings will go here")
}