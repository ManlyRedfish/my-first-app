// data/model/PositionKey.kt
package com.example.rotationappv10.data.model

data class PositionKey(
    val code: String,
    val displayName: String,
    val hasBreak: Boolean,
    val pairingRules: List<String>,
    val isBreak: Boolean = false // Add isBreak property
)