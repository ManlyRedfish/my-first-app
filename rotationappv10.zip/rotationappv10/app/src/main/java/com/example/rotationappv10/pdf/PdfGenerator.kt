// File: pdf/PdfGenerator.kt
package com.example.rotationappv10.pdf

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Build
import android.os.Environment
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import com.example.rotationappv10.R
import com.example.rotationappv10.data.model.Assignment
import com.example.rotationappv10.data.model.PositionKey
import com.example.rotationappv10.data.model.RotationSheet
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import kotlin.math.hypot  // Import hypot
import java.util.Calendar // Import Calendar
import kotlin.math.min

class PdfGenerator(private val context: Context) {

    @RequiresApi(Build.VERSION_CODES.Q)
    fun generatePdf(
        rotationSheet: RotationSheet,
        positionKeys: List<PositionKey>,
        checkpoint: String,
        lane: String,
        lead: String,
        supervisor: String,
        date: String, // Pass date explicitly
        shift: String, //Pass shift explicitly
        blankDate: Boolean

    ): File? {
        val page1Width = 612 //8.5 * 72
        val page1Height = 792 //11 * 72

        val document = PdfDocument()
        val page1Info = PdfDocument.PageInfo.Builder(page1Width, page1Height, 1).create()
        val page1 = document.startPage(page1Info)
        val canvas1: Canvas = page1.canvas

        // --- Paints for different text styles ---
        val titlePaint = Paint().apply {
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textSize = 16f
            color = Color.BLACK
            textAlign = Paint.Align.CENTER
        }

        val headerPaint = Paint().apply {
            typeface = Typeface.DEFAULT
            textSize = 12f
            color = Color.BLACK
        }

        val underlinePaint = Paint().apply {
            strokeWidth = 1f
            color = Color.BLACK
        }

        val tableHeaderPaint = Paint().apply {
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textSize = 10f
            color = Color.BLACK
            textAlign = Paint.Align.CENTER
        }

        val tableTextPaint = Paint().apply {
            typeface = Typeface.DEFAULT
            textSize = 10f
            color = Color.BLACK
            textAlign = Paint.Align.LEFT
        }
        val tableTextPaintCenter = Paint().apply {
            typeface = Typeface.DEFAULT
            textSize = 10f
            color = Color.BLACK
            textAlign = Paint.Align.CENTER
        }
        // --- Logo (Example with VectorDrawable) ---
        val logoBitmap = getLogoBitmapFromVectorDrawable(R.drawable.transportation_security_administration_logo) // Replace with your actual logo
        if (logoBitmap != null) {
            val scaledLogo = Bitmap.createScaledBitmap(logoBitmap, 100, 30, false)  //Adjust size
            canvas1.drawBitmap(scaledLogo, 20f, 20f, null) //Adjust position.
            logoBitmap.recycle() // Important to recycle the original Bitmap
            scaledLogo.recycle()
        }

        // --- Header Text ---
        canvas1.drawText("Transportation Security Administration", page1Width / 2f, 30f, titlePaint)
        canvas1.drawText("TEAM BRADLEY (BDL)", page1Width / 2f, 50f, titlePaint)
        canvas1.drawText("LANE ROTATION SHEET", page1Width / 2f, 70f, titlePaint)
        canvas1.drawText("TSABDL-F1330-16-A1-12", page1Width / 2f, 90f, titlePaint)

        // --- Underlined Fields ---
        val startX = 20f
        var startY = 110f
        val lineHeight = 20f
        val labelSpacing = 5f // Space between label and field

        if(blankDate){
            canvas1.drawText("DATE:", startX, startY, headerPaint)
            canvas1.drawLine(startX + headerPaint.measureText("DATE:") + labelSpacing, startY + 2, startX + 150, startY + 2, underlinePaint)
        }
        else{
            canvas1.drawText("DATE: $date", startX, startY, headerPaint)
            canvas1.drawLine(startX + headerPaint.measureText("DATE: $date") + labelSpacing, startY + 2, startX + 150, startY + 2, underlinePaint)
        }

        canvas1.drawText("Shift: $shift", startX + 160, startY, headerPaint)
        canvas1.drawLine(startX + 160 + headerPaint.measureText("Shift: $shift") + labelSpacing, startY + 2, startX + 160 + 150, startY + 2, underlinePaint)

        startY += lineHeight
        canvas1.drawText("CHECKPOINT:", startX, startY, headerPaint)
        canvas1.drawLine(startX + headerPaint.measureText("CHECKPOINT:") + labelSpacing, startY + 2, startX + 150, startY + 2, underlinePaint)
        canvas1.drawText(checkpoint, startX + headerPaint.measureText("CHECKPOINT:") + labelSpacing + 5, startY, headerPaint) // Show the checkpoint

        canvas1.drawText("LANE:", startX + 160, startY, headerPaint)
        canvas1.drawLine(startX + 160 + headerPaint.measureText("LANE:") + labelSpacing, startY + 2, startX + 160 + 150, startY + 2, underlinePaint)
        canvas1.drawText(lane, startX + 160 + headerPaint.measureText("LANE:") + labelSpacing + 5, startY, headerPaint) //Show the lane


        startY += lineHeight
        canvas1.drawText("LEAD:", startX, startY, headerPaint)
        canvas1.drawLine(startX + headerPaint.measureText("LEAD:") + labelSpacing, startY + 2, startX + 150, startY + 2, underlinePaint)
        canvas1.drawText(lead, startX + headerPaint.measureText("LEAD:") + labelSpacing + 5 , startY, headerPaint) //Show the Lead Name

        canvas1.drawText("SUPERVISOR:", startX + 160, startY, headerPaint)
        canvas1.drawLine(startX + 160 + headerPaint.measureText("SUPERVISOR:") + labelSpacing, startY + 2, startX + 160 + 150, startY + 2, underlinePaint)
        canvas1.drawText(supervisor, startX + 160 + headerPaint.measureText("SUPERVISOR:") + labelSpacing + 5, startY, headerPaint)

        // --- Rotation Table ---
        startY += 2 * lineHeight // More space before the table
        val tableStartX = startX
        var tableStartY = startY
        val nameColumnWidth = 120f
        val timeSlotColumnWidth = 50f // Width for each time slot
        val cellHeight = 20f

        // Table Headers
        canvas1.drawText("NAME", tableStartX, tableStartY, tableHeaderPaint)
        // Assuming you have a way to get the time slots (e.g., from shiftSetting)
        val timeSlots = rotationSheet.assignments.map { it.timeSlot }.distinct().sorted()
        var timeSlotX = tableStartX + nameColumnWidth
        for (timeSlot in timeSlots) {
            canvas1.drawText(timeSlot, timeSlotX, tableStartY, tableHeaderPaint)
            timeSlotX += timeSlotColumnWidth
        }

        tableStartY += cellHeight // Move to the first row of data
        // Table Data

        // Group assignments by officer
        val assignmentsByOfficer = rotationSheet.assignments.groupBy { it.officer }
        for ((officer, assignments) in assignmentsByOfficer) {
            canvas1.drawText(officer?.name ?: "Unassigned", tableStartX, tableStartY, tableTextPaint)

            var currentTimeSlotX = tableStartX + nameColumnWidth
            for (timeSlot in timeSlots) {
                val assignmentForTimeSlot = assignments.find { it.timeSlot == timeSlot }
                val positionCode = assignmentForTimeSlot?.positionKey?.code ?: ""
                canvas1.drawText(positionCode, currentTimeSlotX, tableStartY, tableTextPaintCenter) // Draw centered
                currentTimeSlotX += timeSlotColumnWidth
            }
            tableStartY += cellHeight

        }

        // --- Draw Table Borders ---
        //Horizontal Lines
        val tableBottomY = tableStartY
        // Draw the top border
        canvas1.drawLine(tableStartX, startY - cellHeight, timeSlotX, startY - cellHeight, underlinePaint)
        // Draw lines after each officer row
        var horizontalLineY = startY
        for (i in 0..assignmentsByOfficer.size) { // Include line after the last officer
            canvas1.drawLine(tableStartX, horizontalLineY, timeSlotX, horizontalLineY, underlinePaint)
            horizontalLineY += cellHeight
        }

        //Vertical Lines
        var verticalLineX = tableStartX
        canvas1.drawLine(verticalLineX, startY - cellHeight, verticalLineX, tableBottomY, underlinePaint) // Leftmost border
        for (i in 0..timeSlots.size) { // Include the rightmost border
            canvas1.drawLine(verticalLineX, startY - cellHeight, verticalLineX, tableBottomY, underlinePaint)
            verticalLineX += if (i == 0) nameColumnWidth else timeSlotColumnWidth
        }

        // --- Break Table ---
        // Adjust startY to position the break table below the main table
        var breakTableStartY = tableStartY + 2 * lineHeight // Add some spacing

        // Headers
        canvas1.drawText("NAME", tableStartX, breakTableStartY, tableHeaderPaint)
        canvas1.drawText("BREAKS", tableStartX + nameColumnWidth, breakTableStartY, tableHeaderPaint)
        val timeSlot15min = (tableStartX + nameColumnWidth + (2* timeSlotColumnWidth))
        canvas1.drawText(
            "15 MIN",
            timeSlot15min,
            breakTableStartY,
            tableHeaderPaint
        ) // Centering logic will become important here
        val timeSlot30min = (tableStartX + nameColumnWidth + (4 * timeSlotColumnWidth))
        canvas1.drawText(
            "30 MIN",
            timeSlot30min,
            breakTableStartY,
            tableHeaderPaint
        ) // Centering logic will become important here
        val timeSlotIn = (tableStartX + nameColumnWidth + (5.5 * timeSlotColumnWidth).toFloat())
        canvas1.drawText(
            "IN",
            timeSlotIn,
            breakTableStartY,
            tableHeaderPaint
        ) // Centering logic will become important here
        val timeSlotOut = (tableStartX + nameColumnWidth + (6.5 * timeSlotColumnWidth).toFloat())
        canvas1.drawText(
            "OUT",
            timeSlotOut,
            breakTableStartY,
            tableHeaderPaint
        ) // Centering logic will become important here

        breakTableStartY += cellHeight // Move to the data rows

        // --- Officer Break Data ---
        for ((officer, assignments) in assignmentsByOfficer) {
            canvas1.drawText(officer?.name ?: "Unassigned", tableStartX, breakTableStartY, tableTextPaint)

            //Draw the "X" for the Officer's Breaks, this will need more work
            // You'll need to determine *which* breaks the officer has and draw "X" in the correct columns.
            // This is a placeholder.  You need to get the *actual* break times.

            val officerBreaks = assignments.filter { it.positionKey?.isBreak == true } // Get the break assignments
            if (officerBreaks.isNotEmpty()) {
                for(breaks in officerBreaks){
                    if(breaks.positionKey?.displayName == "Break"){ //Hardcoded for now
                        // Logic to determine position for 15 and 30 mins
                        if(breaks.timeSlot == timeSlots[2]){//Hardcoded for now
                            canvas1.drawText(
                                "X",
                                tableStartX + nameColumnWidth + (2 * timeSlotColumnWidth) + (timeSlotColumnWidth/2),
                                breakTableStartY,
                                tableTextPaintCenter
                            )
                        }
                        if(breaks.timeSlot == timeSlots[8]){//Hardcoded for now
                            canvas1.drawText(
                                "X",
                                tableStartX + nameColumnWidth + (4 * timeSlotColumnWidth) + (timeSlotColumnWidth/2),
                                breakTableStartY,
                                tableTextPaintCenter
                            )
                        }
                        if(breaks.timeSlot == timeSlots[14]){//Hardcoded for now
                            canvas1.drawText(
                                "X",
                                tableStartX + nameColumnWidth + (2 * timeSlotColumnWidth) + (timeSlotColumnWidth/2),
                                breakTableStartY,
                                tableTextPaintCenter
                            )
                        }
                    }
                }
            }
            breakTableStartY += cellHeight // Next officer's break info
        }

        // --- Draw Break Table Borders ---
        // Horizontal Lines
        // Draw the top border
        canvas1.drawLine(tableStartX,  breakTableStartY - (assignmentsByOfficer.size + 1) * cellHeight , tableStartX + nameColumnWidth + (8 * timeSlotColumnWidth) ,  breakTableStartY - (assignmentsByOfficer.size + 1)* cellHeight, underlinePaint)
        //Draw lines after each officer row
        var horizontalBreakLineY = breakTableStartY - (assignmentsByOfficer.size * cellHeight)
        for (i in 0..assignmentsByOfficer.size) { // Include line after the last officer
            canvas1.drawLine(tableStartX, horizontalBreakLineY,  tableStartX + nameColumnWidth + (8 * timeSlotColumnWidth), horizontalBreakLineY, underlinePaint)
            horizontalBreakLineY += cellHeight
        }

        //Vertical Lines
        var verticalBreakLineX = tableStartX
        canvas1.drawLine(verticalBreakLineX, breakTableStartY - ((assignmentsByOfficer.size + 1) * cellHeight), verticalBreakLineX, breakTableStartY, underlinePaint) // Leftmost border
        for (i in 0..7) {
            val columnWidth = if (i == 0) {
                nameColumnWidth
            } else if (i in 1..4) {
                (timeSlotColumnWidth * 1.5).toInt()
            } else {
                timeSlotColumnWidth
            }
            canvas1.drawLine(
                verticalBreakLineX,
                breakTableStartY - ((assignmentsByOfficer.size + 1) * cellHeight),
                verticalBreakLineX,
                breakTableStartY,
                underlinePaint
            )
            verticalBreakLineX += columnWidth.toFloat()
        }

        // --- Legend (Position Key) ---
        var legendStartY = breakTableStartY + 2 * lineHeight  // Position below the break table
        canvas1.drawText("LEGEND:", startX, legendStartY, tableHeaderPaint)
        legendStartY += lineHeight

        for (key in positionKeys) {
            canvas1.drawText("${key.code} - ${key.displayName}", startX, legendStartY, tableTextPaint)
            legendStartY += lineHeight
        }

        document.finishPage(page1)

        // --- File Saving (using getExternalFilesDir) ---
        val directory = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)
        if (directory == null) {
            Log.e("PdfGenerator", "Could not get external files directory")
            return null
        }
        if (!directory.exists()) {
            directory.mkdirs() // Create the directory if it doesn't exist
        }

        val calendar = Calendar.getInstance()
        val fileName =
            "RotationSheet_${calendar.get(Calendar.YEAR)}_${calendar.get(Calendar.MONTH) + 1}_${calendar.get(Calendar.DAY_OF_MONTH)}.pdf"
        val file = File(directory, fileName)

        return try {
            FileOutputStream(file).use { outputStream ->
                document.writeTo(outputStream)
            }
            Log.d("PdfGenerator", "PDF saved to: ${file.absolutePath}")
            file // Return the File object
        } catch (e: IOException) {
            Log.e("PdfGenerator", "Error writing PDF", e)
            null // Return null on error
        } finally {
            document.close()
        }
    }
    private fun getLogoBitmapFromVectorDrawable(drawableId: Int): Bitmap? {
        return try {
            val drawable = ContextCompat.getDrawable(context, drawableId) ?: return null
            drawable.toBitmap()
        } catch (e: Exception) {
            Log.e("PdfGenerator", "Error converting vector drawable to bitmap", e)
            null
        }
    }
    private fun drawDashedLine(
        canvas: Canvas,
        paint: Paint,
        startX: Float,
        startY: Float,
        endX: Float,
        endY: Float,
        dashLength: Float = 5f,
        gapLength: Float = 5f
    ) {
        val distance = hypot(endX - startX, endY - startY)
        val numDashes = (distance / (dashLength + gapLength)).toInt()

        for (i in 0 until numDashes) {
            val x1 = startX + (dashLength + gapLength) * i * (endX - startX) / distance
            val y1 = startY + (dashLength + gapLength) * i * (endY - startY) / distance
            val x2 = minOf(
                startX + (dashLength + gapLength) * i * (endX - startX) / distance + dashLength * (endX - startX) / distance,
                endX
            )
            val y2 = minOf(
                startY + (dashLength + gapLength) * i * (endY - startY) / distance + dashLength * (endY - startY) / distance,
                endY
            )
            canvas.drawLine(x1, y1, x2, y2, paint)
        }
    }
}