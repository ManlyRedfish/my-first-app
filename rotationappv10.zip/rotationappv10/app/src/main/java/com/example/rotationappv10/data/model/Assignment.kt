// data/model/Assignment.kt
package com.example.rotationappv10.data.model

data class Assignment(
    val timeSlot: String,
    val officer: Officer?, // Can be null if unassigned
    val positionKey: PositionKey? // Can be null if no position
)