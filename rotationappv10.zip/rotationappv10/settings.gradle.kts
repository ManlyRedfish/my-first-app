pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS) // Keep this!
    repositories {
        mavenLocal()    // 1. Local builds (if any) - remove in CI
        google()       // 2. Google's Maven (for AndroidX, Compose, etc.)
        maven { url = uri("https://jitpack.io") } //3. JitPack (for pdfbox-android)
        mavenCentral() // 4. Maven Central (as a general fallback)
        // Add any other *necessary* repositories here.
    }
}
rootProject.name = "RotationAppV10"
include(":app")